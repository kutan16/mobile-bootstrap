package com.cg.billing.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.billing.beans.Bill;

public interface BillDAO extends JpaRepository<Bill, Integer>{
	
}
