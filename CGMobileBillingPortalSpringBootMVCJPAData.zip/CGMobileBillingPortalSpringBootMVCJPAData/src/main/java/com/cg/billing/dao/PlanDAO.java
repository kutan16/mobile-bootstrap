package com.cg.billing.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.billing.beans.Plan;

public interface PlanDAO extends JpaRepository<Plan, Integer>{
	
}
